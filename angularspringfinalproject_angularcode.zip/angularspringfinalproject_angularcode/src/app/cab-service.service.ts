import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CabServiceService {
  message:string='';
  constructor(private http:HttpClient,private route:ActivatedRoute,private router:Router) { }

  public dorequest(cab:any){
    return this.http.post("http://localhost:8084/inputrequest",cab,{responseType:'text' as 'json'})
     
   }

   public editcab(id:number){
    return this.http.put("http://localhost:8084/editcab",id,{responseType:'text' as 'json'})
     
   }

   public deletecab(id:number){
    return this.http.post("http://localhost:8084/deletecab/"+id,{responseType:'text' as 'json'})
     
   }

   public bookcab(cabid:number,requestid:number){
    return this.http.post("http://localhost:8084/cabbook/"+cabid+"/"+requestid,{responseType:'text' as 'json'})
     
   }

   public getcabbysourceanddest(source:string,destination:string){
    return this.http.post("http://localhost:8084/getcabbysourceanddest/"+source+"/"+destination,{responseType:'text' as 'json'})   

        
   }

   public getcabbooking(){
    return this.http.post("http://localhost:8084/getcabbooking",{responseType:'text' as 'json'})
     
   }

   public findcabbookingbydest(destination:string){
    return this.http.post("http://localhost:8084/cabbook/"+destination,{responseType:'text' as 'json'})
     
   }
   
   public persisttoDB(booking:any){
    return this.http.post("http://localhost:8084/persisttoDB",booking,{responseType:'text' as 'json'})
     
   }

   public getallcabbookings(){
    return this.http.post("http://localhost:8084/getallcabbookings",{responseType:'text' as 'json'})
     
   }

   public deletefromcab(cab1:any){
    return this.http.post("http://localhost:8084/deletecab/"+cab1,{responseType:'text' as 'json'})
     
   }

   
   public deletefromrequest(request1:any){
    return this.http.post("http://localhost:8084/deleterequest/"+request1,{responseType:'text' as 'json'})
     
   }
   

   

}


