export class Request{
    requestid:number;
    source:string;
    destination:string;
    datetime:string;
    pickup:string;
    userid:number;
    username:string
    }