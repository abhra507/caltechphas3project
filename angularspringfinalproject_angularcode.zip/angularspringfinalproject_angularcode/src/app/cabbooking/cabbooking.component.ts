import { Component,OnInit } from '@angular/core';
import { CabServiceService } from '../cab-service.service';
import { DataserviceService } from '../dataservice.service';
import { HttpClient } from '@angular/common/http';
import { UserServiceService } from '../user-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Cab } from '../Cab';
import { Booking } from '../Booking';

@Component({
  selector: 'app-cabbooking',
  templateUrl: './cabbooking.component.html',
  styleUrls: ['./cabbooking.component.css']
})
export class CabbookingComponent implements OnInit {
cabs:any;
message:any
source:string;
destination:string;
cab:Cab=new Cab();
requestid:number;
drivername:string;

constructor(private service:CabServiceService,private http:HttpClient,private route:ActivatedRoute,private router:Router, private dataService: DataserviceService) { }

ngOnInit(): void {
  this.route.paramMap.subscribe(params=>{
    const idParam=params.get('requestid');

    console.log("the idparam is "+idParam);
    if(idParam!==null){
      this.requestid=+idParam;
           console.log("the requestid is "+this.requestid);
           
    }
    else{
      console.error("id is missing  or null");
    }
    this.source=params.get('source');
    this.destination=params.get('destination');

  })
}

  


public bookcab(cabid:number){
  console.log("the requestid for cab booking is "+this.requestid);
  console.log("the cabid for cab booking is "+cabid);
  let respo=this.service.bookcab(cabid,this.requestid);
  respo.subscribe((response:any)=>
  {this.message=response;console.log("the response in booking for cab booking is "+this.message);this.dataService.setData(this.message);this.router.navigate(['/cabbookingpage'])},
  (error)=>{console.error('Error ',error);}
);


}


public findcabbysourceanddest(){

  let respo=this.service.getcabbysourceanddest(this.source,this.destination);
  console.log(" the source is "+this.source);
  console.log(" the destination is "+this.destination);
  respo.subscribe((data:any)=>this.cabs=data);
  
}






}