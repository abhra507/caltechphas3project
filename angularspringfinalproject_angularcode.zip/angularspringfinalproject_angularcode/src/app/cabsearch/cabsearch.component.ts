import { Component, OnInit } from '@angular/core';
import { CabServiceService } from '../cab-service.service';
import { User } from '../User';
import { Cab } from '../Cab';
import { DataserviceService } from '../dataservice.service';
import { Request } from '../Request';
import { HttpClient } from '@angular/common/http';
import { RequestServiceService } from '../request-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../Booking';

@Component({
  selector: 'app-cabsearch',
  templateUrl: './cabsearch.component.html',
  styleUrls: ['./cabsearch.component.css']
})
export class CabsearchComponent implements OnInit {
  cabs:any;
  destination:string;
  message:any;
  data:string; 
  booking:Booking=new Booking(); 
  cab1:Cab= new Cab();
  request1:Request= new Request();
  constructor(private service:CabServiceService,private http:HttpClient,private route:ActivatedRoute,private router:Router,private dataService: DataserviceService) { }

  
  ngOnInit(): void {
    this.dataService.data$.subscribe((data) => {
    this.booking = data[0];
    this.cabs = data;
    console.log("the booking object is "+this.booking.drivername);
    this.persisttoDB(this.booking);
    this.cab1=data[0].cabid;
    this.deletefromcab(this.cab1);
    console.log("the cab id is deleted from cab table "+this.cab1);
    this.request1=data[0].requestid;
    this.deletefromrequest(this.request1);
    console.log("the requestid id is deleted from request table "+this.request1);
  });
 
  }

  public findcabbookingbydest(){
    let respo=this.service.findcabbookingbydest(this.destination);
    respo.subscribe((data:any)=>this.cabs=data);
  }

  public getallcabbookings(){
    let respo=this.service.getallcabbookings();
    respo.subscribe((data:any)=>this.cabs=data);
  }

  public deletefromcab(cab1:any){
    let respo=this.service.deletefromcab(cab1);
    respo.subscribe((data:any)=>this.message=data);
  }

  

  public persisttoDB(booking:any){
    let respo=this.service.persisttoDB(booking); 
   respo.subscribe((data:any)=>this.message=data);  
  }

  public deletefromrequest(request1:any){
    let respo=this.service.deletefromrequest(request1);
    respo.subscribe((data:any)=>this.message=data);
  }

}


