import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CabsearchComponent } from './cabsearch.component';

describe('CabsearchComponent', () => {
  let component: CabsearchComponent;
  let fixture: ComponentFixture<CabsearchComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CabsearchComponent]
    });
    fixture = TestBed.createComponent(CabsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
