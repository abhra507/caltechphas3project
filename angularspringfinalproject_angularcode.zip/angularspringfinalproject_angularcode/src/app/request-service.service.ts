import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RequestServiceService {

  message:string='';
  destination:string;

  constructor(private http:HttpClient,private route:ActivatedRoute,private router:Router) { }


  ngOnInit(): void {
   this.getallRequests();
  }

  public createRequest(request:any){
    return this.http.post("http://localhost:8084/createrequest",request,{responseType:'text' as 'json'})
     
   }
 
   public getRequestsbydestination(destination:any){
     return this.http.post("http://localhost:8084/request/"+destination,{responseType:'text' as 'json'})
      
    }


    public getallRequests(){
      return this.http.post("http://localhost:8084/getallrequests",{responseType:'text' as 'json'})
       
     }


     public getallRequestsbyId(id:number){
      return this.http.post("http://localhost:8084/getallrequestsbyId/"+id,{responseType:'text' as 'json'})
       
     }

     public editrequest(request:any){
      return this.http.post("http://localhost:8084/updateBydestination",request,{responseType:'text' as 'json'})
       
     }


     public deleterequest(id:number){
      return this.http.post("http://localhost:8084/deletebyid/"+id,{responseType:'text' as 'json'})
       
     }

  

     
    }
