import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RequestServiceService } from '../request-service.service';
import { Request } from '../Request';


@Component({
  selector: 'app-editrequest',
  templateUrl: './editrequest.component.html',
  styleUrls: ['./editrequest.component.css']
})
export class EditrequestComponent implements OnInit {
  id:number=0;
  requestid:number;
  destination:string;
  source:string;
  datetime:string;
  pickup:string;
  request:Request=new Request();
  message:string='';
  requests:any;
  constructor(private http:HttpClient,private route:ActivatedRoute,private router:Router,private service:RequestServiceService) { }


  ngOnInit(): void {
    this.route.paramMap.subscribe(params=>{
      const idParam=params.get('requestid');
      console.log("the idparam is "+idParam);
      if(idParam!==null){
        this.requestid=+idParam;
        console.log("the requestid is "+this.requestid);
        this.getallRequestsbyId(this.requestid);
       
      }
      else{
        console.error("id is missing  or null");
      }


    })
  }




  getallRequestsbyId(id:number){
    let respo=this.service.getallRequestsbyId(id);
    console.log("the respo value is "+respo );
        respo.subscribe((response:any)=>
      {
        console.log("the response is "+response);
        const request=response[0];
        this.request.source=request.source;
        console.log("the source is  "+this.request.source);
        this.request.destination=request.destination;
        this.request.datetime=request.datetime;
        this.request.pickup=request.pickup;
      },
      (error)=>{console.error('Error fetching the product',error);}
    );
  }



   public editrequest(){
    const request={
      requestid:this.requestid,
      destination:this.request.destination
    
    };
    console.log("the request id is "+request.requestid);
    let respo=this.service.editrequest(request);
    respo.subscribe((data:any)=>{this.requests=data;this.router.navigate(['/request'])});
  }
  
  


}