export class User{
    userid:number;
    name:string;
    email:string;
    password:string;
    retypepassword:string;
    }