import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { HttpClient } from '@angular/common/http';
import { UserServiceService } from '../user-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { JsonPipe } from '@angular/common';


@Component({
  selector: 'app-registration',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
user:User=new User();
message:any
  constructor(private service:UserServiceService,private http:HttpClient,private route:ActivatedRoute,private router:Router) { }


  ngOnInit(): void {
  }

  public registerNow(){
    console.log("the user name "+this.user.name); 
  let respo=this.service.doregistration(this.user);  
  respo.subscribe((data:any)=>this.message=data);   

  }


}