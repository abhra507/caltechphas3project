import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { InputrequestComponent } from './inputrequest/inputrequest.component';
import { RequestsComponent } from './requests/requests.component';
import { CabbookingComponent } from './cabbooking/cabbooking.component';
import { CabsearchComponent } from './cabsearch/cabsearch.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { EditrequestComponent } from './editrequest/editrequest.component';


const routes:Routes=[
  {path:"",redirectTo:"register",pathMatch:"full"},
  {path:"register",component:RegisterComponent},
  {path:"login",component:LoginComponent},
  {path:'inputrequest/:data',component:InputrequestComponent},
  {path:'request',component:RequestsComponent},  
  {path:"cabbook/:requestid/:source/:destination",component:CabbookingComponent},
  {path:'edit/:requestid',component:EditrequestComponent},
  {path:"cabbookingpage",component:CabsearchComponent}
  ]

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    InputrequestComponent,
    RequestsComponent,
    CabbookingComponent,
    CabsearchComponent,
    EditrequestComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    [RouterModule.forRoot(routes)]
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
