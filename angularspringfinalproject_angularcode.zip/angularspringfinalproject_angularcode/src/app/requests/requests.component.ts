import { Component,OnInit } from '@angular/core';
import { RequestServiceService } from '../request-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-requests',
  templateUrl: './requests.component.html',
  styleUrls: ['./requests.component.css']
})
export class RequestsComponent {
  requests:any;
  data:any;
  destination:any
 

  constructor(private service:RequestServiceService,private route:ActivatedRoute,private http:HttpClient) {  }

  ngOnInit(): void { 
  this.getallRequests();
  }

  public findrequestbydest(){
    let respo=this.service.getRequestsbydestination(this.destination);
    respo.subscribe((data:any)=>this.requests=data);
  }
  
  public deleterequest(requestid:number){
    let respo=this.service.deleterequest(requestid);
    respo.subscribe((data:any)=>{this.requests=data;this.getallRequests();});
  }

  public getallRequests(){
    let respo=this.service.getallRequests();
    respo.subscribe((data:any)=>this.requests=data);
  }

}







