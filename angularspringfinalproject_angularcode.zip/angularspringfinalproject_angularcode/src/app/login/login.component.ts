import { Component, OnInit} from '@angular/core';
import { User } from '../User';
import { HttpClient } from '@angular/common/http';
import { UserServiceService } from '../user-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
user:User=new User();
message:any
object:any;
sharedData: any;
  constructor(private service:UserServiceService,private http:HttpClient,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
  }
  public loginnow(){
  let respo=this.service.dologin(this.user);
   respo.subscribe((response:any)=>
   {this.message=response;console.log("the response msg is "+this.message);
   var splitted = this.message.split(",", 3); 
   if(this.message.includes('Welcome'))
   {
    this.router.navigate(['/inputrequest',splitted[0]+", "+splitted[1]+", "+splitted[2]])
   }
   },   
   (error)=>{console.error('Error in logging of the user',error);}
 );

  }


 public registerNow(){
   this.router.navigate(['/register']) 
  }



}


