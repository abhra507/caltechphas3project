import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputrequestComponent } from './inputrequest.component';

describe('InputrequestComponent', () => {
  let component: InputrequestComponent;
  let fixture: ComponentFixture<InputrequestComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [InputrequestComponent]
    });
    fixture = TestBed.createComponent(InputrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
