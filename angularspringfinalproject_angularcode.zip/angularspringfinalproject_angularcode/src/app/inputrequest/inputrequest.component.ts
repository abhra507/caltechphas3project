import { Component , OnInit } from '@angular/core';
import { User } from '../User';
import { Cab } from '../Cab';
import { Request } from '../Request';
import { HttpClient } from '@angular/common/http';
import { CabServiceService } from '../cab-service.service';
import { RequestServiceService } from '../request-service.service';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-inputrequest',
  templateUrl: './inputrequest.component.html',
  styleUrls: ['./inputrequest.component.css']
})
export class InputrequestComponent implements OnInit{
user:User=new User();
request:Request=new Request();
message:string
data:string
data1:string
constructor(private service:RequestServiceService,private http:HttpClient,private route:ActivatedRoute,private router:Router) { 
   this.route.paramMap.subscribe(params => {
    this.data = params.get('data');
    console.log("the data in inputsearch is "+this.data);
    var splitted = this.data.split(",", 3);
    this.request.username=splitted[1];
    var y: number = +splitted[2];
    this.request.userid=y;
    console.log("the request userid and username  are "+this.request.username+" ,"+this.request.userid);
    this.data1=splitted[0]+" "+splitted[1]
  });

}

ngOnInit(): void {
}
public requestNow(){ 
 console.log("the requests are "+this.request.username+" "+this.request.userid);
let respo=this.service.createRequest(this.request);
 respo.subscribe((response:any)=>
 {this.message=response;this.router.navigate(['/request'])},
 (error)=>{console.error('Error in requesting',error);}
);


}

}


