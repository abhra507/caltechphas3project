export class Booking{
    cabid:number;
    requestid:number;
    cabname:string;
    drivername:string;
    fare:number;
    datetime:string;
    source:string;
    destination:string
    pickup:string
    userid:number;
    username:string
    }