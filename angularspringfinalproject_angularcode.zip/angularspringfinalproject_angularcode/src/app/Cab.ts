export class Cab{
    cabid:number;
    cabname:string;
    drivername:string;
    source:string;
    destination:string
    fare:number; 
    }