import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  message:string='';

  constructor(private http:HttpClient,private route:ActivatedRoute,private router:Router) { }
  public doregistration(user:any){
   return this.http.post("http://localhost:8084/register",user,{responseType:'text' as 'json'})
    
  }

  public dologin(user:any){
    return this.http.post("http://localhost:8084/login",user,{responseType:'text' as 'json'})
     
   }
  
}
