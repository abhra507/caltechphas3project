package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springangularfinalprojectms1ApplicationTests {

	@Test
	void contextLoads() {
	}	
	
}
