package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface CustomRequestRepository extends JpaRepository<Booking,Integer> {
	
	//String query1="select c.cabname,c.drivername,c.fare,r.pickup,r.source,r.destination,r.requestid,c.cabid  from request r join   cab c on r.source=c.source AND r.destination=c.destination AND r.requestid=?1 AND c.cabid=?2";
//String query1="select rc.cabname,rc.drivername,rc.fare,r.pickup,r.source,r.destination,r.requestid,rc.cabid from Request r join r.cabs rc  on r.source=rc.source and r.destination=rc.destination where r.requestid=?1 and rc.cabid=?2";
@Query(value = "select b.cabid,a.requestid,a.userid,a.username,b.cabname,b.drivername,b.fare,a.datetime,a.source,a.destination,a.pickup  from request a INNER JOIN   cab b " + "ON a.source=b.source AND a.destination=b.destination " + "where  b.cabid=:cabid  AND a.requestid=:requestid ", nativeQuery =true)
public List<Booking> findbyrequestidcabid(@Param("cabid") int cabid,@Param("requestid") int requestid);


String query1="select booking from Booking booking where booking.destination=?1";
@Query(query1)
public List<Booking> findbydestination(String destination);
}
