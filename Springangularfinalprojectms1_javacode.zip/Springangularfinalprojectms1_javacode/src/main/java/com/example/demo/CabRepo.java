package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CabRepo extends JpaRepository<Cab,Integer>{

	String query="select cab from Cab cab where cab.destination=?1";
	@Query(query)
	public Cab findbydestination(String destination);
	
	
	String query1="select cab from Cab cab where cab.source=?1 and cab.destination=?2";
	@Query(query1)
	public List<Cab> findbysourceanddestination(String source,String destination);
	

	
}

