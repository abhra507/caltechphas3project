package com.example.demo;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@CrossOrigin(origins = "*")
public class BookingController {
	Logger log=Logger.getAnonymousLogger();
	
	@Autowired
	BookingService se;
	
	@ResponseBody
	@RequestMapping("/cabbook/{cabid}/{requestid}")
	public List<Booking> cabbook(HttpServletRequest request,HttpServletResponse response,@PathVariable("cabid") int cabid,@PathVariable("requestid") int requestid) {
		
			return se.bookbycabidandreqestid(cabid,requestid);
		}

	@ResponseBody
	@RequestMapping("/persisttoDB")
	public String persist(HttpServletRequest request,HttpServletResponse response,@RequestBody Booking booking) {
		log.info("the persist object is "+booking.toString());
		
		Booking b=se.persisttoDB(booking);
		if (b != null)
		{
			return "persisted";
		}
		else
		{
			return "not persisted";
		}
		}
	
	
	@ResponseBody
	@RequestMapping("/getallcabbookings")
	public List<Booking> getallcabbookings(HttpServletRequest request,HttpServletResponse response) {
				
		return se.getallbookings();

		}
		
	@ResponseBody
	@RequestMapping("/cabbook/{destination}")
	public List<Booking> updatebydestination(@PathVariable("destination") String destination) {	
		return se.findbydestination(destination);
	}
	
	
}
