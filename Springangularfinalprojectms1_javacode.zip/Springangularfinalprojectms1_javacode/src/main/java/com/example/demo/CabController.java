package com.example.demo;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

@Controller
@CrossOrigin(origins = "*")
public class CabController {
Logger log=Logger.getAnonymousLogger();
@Autowired
CabService obj;




@ResponseBody
@RequestMapping("/getcabbysourceanddest/{source}/{destination}")
public List<Cab> findbysourceanddestination(HttpServletRequest request,HttpServletResponse response,@PathVariable("destination") String destination,@PathVariable("source") String source) {
return obj.findbysourceanddestination(source, destination);
	
}




/*@RequestMapping("/getcabbysourceanddest/{source}/{destination}")
public ModelAndView findbysourceanddestination(HttpServletRequest request,HttpServletResponse response,@PathVariable("destination") String destination,@PathVariable("source") String source) {
	ModelAndView mv=new ModelAndView();	
List<Cab> cab=obj.findbysourceanddestination(source, destination);
	mv.setViewName("cabbooking.component");
	mv.addObject("cabs", cab);
	return mv;
	
}*/




/*
@ResponseBody
@RequestMapping("/getcabbysourceanddest/{id}")
public Optional<Request> getallbyId(@PathVariable("id") int id){
		return se.getbyId(id);
	}


@ResponseBody
@RequestMapping("/getcabbooking")
public List<Request> getall(){
	 return se.getall();
	}


@ResponseBody
@RequestMapping(value="/findcabbookingbydest/{destination}",method=RequestMethod.GET)
public Request getRequestsbydestination(HttpServletRequest request,HttpServletResponse response,@PathVariable("destination") String destination) {
	Request e=se.findbydestination(destination);
	return e;
	
}
*/
@ResponseBody
@RequestMapping("/deletecab/{id}")
public String delete(@PathVariable("id") String id) {
	int id1=Integer.parseInt(id);  
	 return obj.delete(id1);
	

}

/*
@ResponseBody
@RequestMapping("/editcab")
public Request updatebydestination(@RequestBody Request e) {
	log.info("the request object is "+e.toString());
	return se.updateRequest(e);
}*/





}
