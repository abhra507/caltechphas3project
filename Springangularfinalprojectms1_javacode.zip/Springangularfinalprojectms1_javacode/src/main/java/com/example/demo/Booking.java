package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Booking {
	@Id
	private int cabid;
    private int requestid;
    private int userid;
    private String username;
    private String cabname;
    private String drivername;
    private int fare;
    private String datetime;
    private String source;
    private String destination;
    private String pickup;
}
