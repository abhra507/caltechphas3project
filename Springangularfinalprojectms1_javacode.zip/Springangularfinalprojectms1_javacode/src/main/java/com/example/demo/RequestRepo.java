package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface RequestRepo extends JpaRepository<Request,Integer>{
	
   	String query="select request from Request request where request.destination=?1";
    @Query(query)
     public List<Request> findbydestination(String destination);
	

}

