package com.example.demo;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CabService {
	Logger log=Logger.getAnonymousLogger();
	
	@Autowired
	CabRepo re;
	



	
	public List<Cab> findbysourceanddestination(String source,String destination)
	{
		return re.findbysourceanddestination(source,destination);
	}

	
	public List<Cab> getall()
	{
		return re.findAll();
	}

	
	//delete 
	public String delete(int id) {
		re.deleteById(id);
		return "deleted id of "+id;
	}


}